/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package us.mattgreen;
import java.util.Scanner;

import java.util.ArrayList;

/**
 *
 * @author bitstudent
 */
public class Input 
{
    public void prompt(ArrayList<Talkable> zoo)
    {
        Scanner k = new Scanner(System.in);
        boolean yes = true;
        
        do
        {
            System.out.println("Do you want to add to the zoo? [Y/N]");
            String ansFirst = k.nextLine().toUpperCase();
            
            if(ansFirst.equals("Y"))
            {
                System.out.println("Is this a dog, cat or people?");
                String thing = k.nextLine().toUpperCase();

                switch(thing)
                {
                    case "DOG":
                    {
                        boolean answer = false;
                        boolean dogOne = true;
                        String dogName;
                        while(answer==false)
                        {
                            System.out.println("Is the dog friendly? [Y/N]");
                            String ansOne = k.nextLine().toUpperCase();
                            if(ansOne.equals("Y"))
                            {
                                dogOne = true;
                                answer = true;
                            }
                            else if(ansOne.equals("N"))
                            {
                                dogOne = false;
                                answer = true;
                            }
                        }

                        System.out.println("What is the dogs name?");
                        dogName = k.nextLine();
                        zoo.add(new Dog(dogOne,dogName));
                        break;
                    }
                    case "CAT":
                    {
                        String catName;
                        int catKDA = Integer.MAX_VALUE;

                        System.out.println("What is the cats name?");
                        catName = k.nextLine();

                        while(catKDA == Integer.MAX_VALUE)
                        {
                            System.out.println("How many kills does "+catName+" have?");
                            try
                            {
                                catKDA = Integer.parseInt(k.nextLine());
                            }
                            catch(NumberFormatException e)
                            {
                                System.out.println("Enter a real number dude!");
                            }
                        }
                        zoo.add(new Cat(catKDA,catName));
                        break;
                    }
                    case "PEOPLE":
                    {
                        boolean answerTwo = false;
                        String peopleName;
                        System.out.println("What is the People's name?");
                        peopleName = k.nextLine();
                        do
                        {
                            System.out.println("Is this people a student? [Y/N]");
                            String ans = k.nextLine().toUpperCase();

                            if(ans.equals("Y"))
                            {
                                int peopleAge = Integer.MAX_VALUE;

                                while(peopleAge == Integer.MAX_VALUE)
                                {
                                    System.out.println("How old is "+peopleName+"?");
                                    try
                                    {
                                        peopleAge = Integer.parseInt(k.nextLine());
                                    }
                                    catch(NumberFormatException e)
                                    {
                                        System.out.println("Enter a real number dude!");
                                    }
                                }
                                zoo.add(new Student(peopleAge, peopleName));
                            }
                            else if(ans.equals("N"))
                            {
                                System.out.println("People cannot talk unless they are students");
                            }
                            else
                            {
                                answerTwo = true;
                            }
                        }while(answerTwo);
                        break;
                    }
                }
            }
            else if(ansFirst.equals("N"))
            {
                System.out.println("Sweet");
                yes = false;
            }
        }while(yes);
    }
}
